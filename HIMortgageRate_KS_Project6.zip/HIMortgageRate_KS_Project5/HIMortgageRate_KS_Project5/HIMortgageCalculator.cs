﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HIMortgageRate_KS_Project5
{
    public partial class HIMortgageCalculator : Form
    {

        List<decimal> homePricesList = new List<decimal>();
        

            decimal homePrice = 0;
            decimal downPay = 0;
            double intRate = 0;
            int loanTerm = 0;
            decimal monthlyPropTax = 0;
            decimal monthlyLoanPay = 0;
            decimal totalMonthlyMortgagePay = 0;
            decimal aveHomePrice = 0;
            decimal minHomePrice = 0;
            decimal maxHomePrice = 0;

        //private decimal MonthlyLoanPaymentCalculation(decimal monthlyLoanPayment, ref decimal homePrice, ref int loanTerm, ref double propTax, ref decimal downPay);
        //{
        //    monthlyLoanPayment = ((homePrice - downPay) * intRate) / (1 - (1 + intRate) - loanTerm);

        //    return MonthlyLoanPayment;
        //}

        private decimal CalculateMonthlyPayment(decimal homePrice, decimal downPay, double intRate, int loanTerm)
        {
            loanTerm *= 12;
            double interest = (intRate / 100);
            decimal monthlyPay = ((homePrice - downPay)*(decimal)(intRate / 12))/(decimal)(1- Math.Pow((1+interest/12), -1 *loanTerm));
            return monthlyPay;
        }

        private decimal AverageHomePrices(List<decimal>homePricesList)
        {
            decimal totalHomePrices = 0;
            decimal average;                    //to hold the average

            //calculate the total scores
            foreach (decimal homePrice in homePricesList)
            {
                totalHomePrices += homePrice;
            }

            //calculate average of homePrices
            average = (decimal)totalHomePrices / homePricesList.Count;

            //return average
            return average;
        }

        //private decimal MaxHomePrices(List<decimal>homePricesList)
        //{

        //}

        public HIMortgageCalculator()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            homePriceTextBox.Clear();
            downPayTextBox.Clear();
            intRateTextBox.Clear();
            loanTermTextBox.Clear();
            resTypeComboBox.SelectedIndex = -1;
            stateComboBox.SelectedIndex = -1;
            monthlyLoanLabel.Text = "$0.00";
            monthlyTaxLabel.Text = "$0.00";
            monthlyMortgagePayLabel.Text = "$0.00";
            aveHomePriceLabel.Text = "$0.00";
            maxHomePriceLabel.Text = "$0.00";
            minHomePriceLabel.Text = "$0.00";

            homePriceTextBox.Focus();
        }

        private void HIMortgageCalculator_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Our company has recently made a shift in corporate and have established an inovative approach to claim all 50 states for quota.", "Important Company Information!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            

            //I do validations anyways

            //validate residenceType
            if ((int)resTypeComboBox.SelectedIndex == -1)
            {
                MessageBox.Show("Select a residence type.", "Unable to process client information:", MessageBoxButtons.OK, MessageBoxIcon.Error);
                resTypeComboBox.Focus();
                return;
            }

            //validation for state select
            if ((int)stateComboBox.SelectedIndex == -1)
            {
                MessageBox.Show("Select a state.", "Unable to process client information:", MessageBoxButtons.OK, MessageBoxIcon.Error);
                stateComboBox.Focus();
                return;
            }

            //validate homePrice
            if (!decimal.TryParse(homePriceTextBox.Text, out homePrice)|| homePrice < 0)
            {
                MessageBox.Show("Input home price.", "Unable to process client information:", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
                return;
            }
            
            //validate downPayment
            if (!decimal.TryParse(downPayTextBox.Text, out downPay) || downPay < 0)
            {
                MessageBox.Show("Input down payment made on home.", "Unable to process client information:", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }

            //validate loanTerm
            if (!int.TryParse(loanTermTextBox.Text, out loanTerm) || loanTerm < 0)
            {
                MessageBox.Show("Input loan term declaired on home.", "Unable to process client information:", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }

            //validate interestRate
            if (!double.TryParse(intRateTextBox.Text, out intRate) || intRate < 0)
            {
                MessageBox.Show("Input interest rate on home.", "Unable to process client information:", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }

            homePricesList.Add(homePrice);



            //state property taxes

            //Alabama
            if (stateComboBox.SelectedIndex == 1)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 65000)
                    {
                        monthlyPropTax = (((decimal)1.08 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.08 / (1000 / homePrice) - (65000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.08 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Arkansas
            if (stateComboBox.SelectedIndex == 2)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 19000)
                    {
                        monthlyPropTax = (((decimal)1.97 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.97 / (1000 / homePrice) - (19000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.97 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Arizona
            if (stateComboBox.SelectedIndex == 3)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 100000)
                    {
                        monthlyPropTax = (((decimal)1.97 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.97 / (1000 / homePrice) - (100000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.97 / loanTerm) * (homePrice / 1000)));
                }
            }

            //alaska.. stupid alaska, I forgot you existed
            if (stateComboBox.SelectedIndex == 0)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 100000)
                    {
                        monthlyPropTax = (((decimal)1.97 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.97 / (1000 / homePrice) - (100000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.97 / loanTerm) * (homePrice / 1000)));
                }
            }

            //California
            if (stateComboBox.SelectedIndex == 4)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 95000)
                    {
                        monthlyPropTax = (((decimal)1.14 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.14 / (1000 / homePrice) - (95000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.14 / loanTerm) * (homePrice / 1000)));
                }
            }

            //colorado
            if (stateComboBox.SelectedIndex == 5)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 60000)
                    {
                        monthlyPropTax = (((decimal)1.14 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.14 / (1000 / homePrice) - (60000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.14 / loanTerm) * (homePrice / 1000)));
                }
            }

            //CT
            if (stateComboBox.SelectedIndex == 6)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 70000)
                    {
                        monthlyPropTax = (((decimal)1.14 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.14 / (1000 / homePrice) - (70000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.14 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Delaware
            if (stateComboBox.SelectedIndex == 7)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 95000)
                    {
                        monthlyPropTax = (((decimal)1.14 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.14 / (1000 / homePrice) - (95000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.14 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Florida
            if (stateComboBox.SelectedIndex == 8)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 50000)
                    {
                        monthlyPropTax = (((decimal)1.14 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.14 / (1000 / homePrice) - (50000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.14 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Georgia
            if (stateComboBox.SelectedIndex == 9)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 70000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (70000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }


            //hawaii
            if (stateComboBox.SelectedIndex == 10)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 80000)
                    {
                        monthlyPropTax = (((decimal)3.5 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)3.5 / (1000 / homePrice) - (80000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(3.5 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Idaho
            if (stateComboBox.SelectedIndex == 11)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 50000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (50000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Illinois
            if (stateComboBox.SelectedIndex == 12)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 40000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (40000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Indiana
            if (stateComboBox.SelectedIndex == 13)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 65000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (65000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Iowa
            if (stateComboBox.SelectedIndex == 14)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 30000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (30000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Kansas
            if (stateComboBox.SelectedIndex == 15)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 25000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (25000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Kentucky
            if (stateComboBox.SelectedIndex == 16)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 70000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (70000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Louisiana
            if (stateComboBox.SelectedIndex == 17)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 75000)
                    {
                        monthlyPropTax = (((decimal)1.97 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.97 / (1000 / homePrice) - (75000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.97 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Maine
            if (stateComboBox.SelectedIndex == 18)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 55000)
                    {
                        monthlyPropTax = (((decimal)1.97 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.97 / (1000 / homePrice) - (55000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.97 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Maryland
            if (stateComboBox.SelectedIndex == 19)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 95000)
                    {
                        monthlyPropTax = (((decimal)1.97 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.97 / (1000 / homePrice) - (95000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.97 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Mass
            if (stateComboBox.SelectedIndex == 20)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 90000)
                    {
                        monthlyPropTax = (((decimal)1.14 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.14 / (1000 / homePrice) - (90000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.14 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Michigan
            if (stateComboBox.SelectedIndex == 21)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 85000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (85000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Minnesota
            if (stateComboBox.SelectedIndex == 22)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 65000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (65000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Mississippi
            if (stateComboBox.SelectedIndex == 23)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 45000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (45000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Missouri
            if (stateComboBox.SelectedIndex == 24)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 65000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (65000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Montana
            if (stateComboBox.SelectedIndex == 25)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 45000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (45000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Nebraska
            if (stateComboBox.SelectedIndex == 26)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 35000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (35000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Nevada
            if (stateComboBox.SelectedIndex == 27)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 105000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (105000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //New Hampshire
            if (stateComboBox.SelectedIndex == 28)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 75000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (75000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //New Jersey
            if (stateComboBox.SelectedIndex == 29)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 75000)
                    {
                        monthlyPropTax = (((decimal)2.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)2.05 / (1000 / homePrice) - (75000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(2.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //New Mexico
            if (stateComboBox.SelectedIndex == 30)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 85000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (85000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //New York
            if (stateComboBox.SelectedIndex == 31)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 95000)
                    {
                        monthlyPropTax = (((decimal)3.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)3.05 / (1000 / homePrice) - (95000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(3.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //North Carolina
            if (stateComboBox.SelectedIndex == 32)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 45000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (45000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //North Dakota
            if (stateComboBox.SelectedIndex == 33)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 50000)
                    {
                        monthlyPropTax = (((decimal)1.01 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.01 / (1000 / homePrice) - (50000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.01 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Ohio
            if (stateComboBox.SelectedIndex == 34)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 68000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (68000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Oklahoma
            if (stateComboBox.SelectedIndex == 35)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 45000)
                    {
                        monthlyPropTax = (((decimal)1.01 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.01 / (1000 / homePrice) - (45000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.01 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Oregon
            if (stateComboBox.SelectedIndex == 36)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 75000)
                    {
                        monthlyPropTax = (((decimal)1.95 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.95 / (1000 / homePrice) - (75000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.95 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Pennsylvania
            if (stateComboBox.SelectedIndex == 37)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 85000)
                    {
                        monthlyPropTax = (((decimal)1.41 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.41 / (1000 / homePrice) - (85000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.41 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Rhode Island
            if (stateComboBox.SelectedIndex == 38)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 75000)
                    {
                        monthlyPropTax = (((decimal)2.95 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)2.95 / (1000 / homePrice) - (75000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(2.95 / loanTerm) * (homePrice / 1000)));
                }
            }

            //South Carolina
            if (stateComboBox.SelectedIndex == 39)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 45000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (45000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }


            //South Dakota
            if (stateComboBox.SelectedIndex == 40)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 25000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (25000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Tennessee
            if (stateComboBox.SelectedIndex == 41)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 45000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (45000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Texas
            if (stateComboBox.SelectedIndex == 42)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 60000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (60000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Utah
            if (stateComboBox.SelectedIndex == 43)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 37500)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (37500)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Vermont
            if (stateComboBox.SelectedIndex == 44)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 45000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (45000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Virginia
            if (stateComboBox.SelectedIndex == 45)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 45000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (45000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Washington State
            if (stateComboBox.SelectedIndex == 46)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 57000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (57000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //West Virginia
            if (stateComboBox.SelectedIndex == 47)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 38000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (38000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }


            //Wisconsin
            if (stateComboBox.SelectedIndex == 48)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 85000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (85000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //Wyoming
            if (stateComboBox.SelectedIndex == 49)
            {
                if (resTypeComboBox.SelectedIndex == 0)
                {
                    if (homePrice <= 45000)
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice)));
                    }
                    else
                    {
                        monthlyPropTax = (((decimal)1.05 / (1000 / homePrice) - (45000)));
                    }

                }
                else
                {
                    monthlyPropTax = (((decimal)(1.05 / loanTerm) * (homePrice / 1000)));
                }
            }

            //calculations
            //monthlyPropTax = (((decimal)3.5 / 1000) * homePrice - homePrice);
            //monthlyLoanPay = ((homePrice - downPay)* intRate) / (1 - (1 + intRate) * (-1 + (-1 - intRate)*loanTerm));
            monthlyLoanPay = CalculateMonthlyPayment(homePrice,  downPay, intRate, loanTerm);
            totalMonthlyMortgagePay = monthlyPropTax + monthlyLoanPay;




            //display labels
            monthlyLoanLabel.Text = monthlyLoanPay.ToString("C");
            monthlyTaxLabel.Text = monthlyPropTax.ToString("C");
            monthlyMortgagePayLabel.Text = totalMonthlyMortgagePay.ToString("C");

            //minHomePrice = homePricesList.Min
            //maxHomePrice = homePricesList


            //new label display
            aveHomePriceLabel.Text = AverageHomePrices(homePricesList).ToString("C");
            maxHomePriceLabel.Text = homePricesList.Max().ToString("C");
            minHomePriceLabel.Text = homePricesList.Min().ToString("C");

        }

        private void resetHousingRecordsButton_Click(object sender, EventArgs e)
        {
            aveHomePriceLabel.Text = "";
            maxHomePriceLabel.Text = "";
            minHomePriceLabel.Text = "";

            homePriceTextBox.Focus();
        }
    }
}
