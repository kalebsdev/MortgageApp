﻿namespace HIMortgageRate_KS_Project5
{
    partial class HIMortgageCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mortgageGroupBox = new System.Windows.Forms.GroupBox();
            this.stateComboBox = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.resTypeComboBox = new System.Windows.Forms.ComboBox();
            this.loanTermTextBox = new System.Windows.Forms.TextBox();
            this.intRateTextBox = new System.Windows.Forms.TextBox();
            this.downPayTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.homePriceTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.monthlyLoanLabel = new System.Windows.Forms.Label();
            this.monthlyTaxLabel = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.monthlyMortgagePayLabel = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.calcButton = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.maxHomePriceLabel = new System.Windows.Forms.Label();
            this.aveHomePriceLabel = new System.Windows.Forms.Label();
            this.minHomePriceLabel = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.resetHousingRecordsButton = new System.Windows.Forms.Button();
            this.mortgageGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // mortgageGroupBox
            // 
            this.mortgageGroupBox.Controls.Add(this.stateComboBox);
            this.mortgageGroupBox.Controls.Add(this.label7);
            this.mortgageGroupBox.Controls.Add(this.resTypeComboBox);
            this.mortgageGroupBox.Controls.Add(this.loanTermTextBox);
            this.mortgageGroupBox.Controls.Add(this.intRateTextBox);
            this.mortgageGroupBox.Controls.Add(this.downPayTextBox);
            this.mortgageGroupBox.Controls.Add(this.label5);
            this.mortgageGroupBox.Controls.Add(this.label4);
            this.mortgageGroupBox.Controls.Add(this.label3);
            this.mortgageGroupBox.Controls.Add(this.label2);
            this.mortgageGroupBox.Controls.Add(this.homePriceTextBox);
            this.mortgageGroupBox.Controls.Add(this.label1);
            this.mortgageGroupBox.Location = new System.Drawing.Point(161, 42);
            this.mortgageGroupBox.Name = "mortgageGroupBox";
            this.mortgageGroupBox.Size = new System.Drawing.Size(279, 293);
            this.mortgageGroupBox.TabIndex = 0;
            this.mortgageGroupBox.TabStop = false;
            this.mortgageGroupBox.Text = "Mortgage Info:";
            // 
            // stateComboBox
            // 
            this.stateComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.stateComboBox.FormattingEnabled = true;
            this.stateComboBox.Items.AddRange(new object[] {
            "AK",
            "AL",
            "AR",
            "AZ",
            "CA",
            "CO",
            "CT",
            "DE",
            "GA",
            "FL",
            "HI",
            "ID",
            "IL",
            "IN",
            "IA",
            "KA",
            "KE",
            "LA",
            "ME",
            "ML",
            "MA",
            "MI",
            "MN",
            "MS",
            "MO",
            "MT",
            "NA",
            "NE",
            "NH",
            "NJ",
            "NM",
            "NY",
            "NC",
            "ND",
            "OH",
            "OK",
            "PY",
            "RH",
            "TN",
            "TX",
            "UT",
            "VT",
            "VI",
            "WA",
            "WV",
            "WI",
            "WY"});
            this.stateComboBox.Location = new System.Drawing.Point(144, 246);
            this.stateComboBox.Name = "stateComboBox";
            this.stateComboBox.Size = new System.Drawing.Size(100, 21);
            this.stateComboBox.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(103, 249);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "State:";
            // 
            // resTypeComboBox
            // 
            this.resTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.resTypeComboBox.FormattingEnabled = true;
            this.resTypeComboBox.Items.AddRange(new object[] {
            "Primary",
            "Investment"});
            this.resTypeComboBox.Location = new System.Drawing.Point(144, 206);
            this.resTypeComboBox.Name = "resTypeComboBox";
            this.resTypeComboBox.Size = new System.Drawing.Size(100, 21);
            this.resTypeComboBox.TabIndex = 10;
            // 
            // loanTermTextBox
            // 
            this.loanTermTextBox.Location = new System.Drawing.Point(144, 165);
            this.loanTermTextBox.Name = "loanTermTextBox";
            this.loanTermTextBox.Size = new System.Drawing.Size(100, 20);
            this.loanTermTextBox.TabIndex = 8;
            // 
            // intRateTextBox
            // 
            this.intRateTextBox.Location = new System.Drawing.Point(144, 123);
            this.intRateTextBox.Name = "intRateTextBox";
            this.intRateTextBox.Size = new System.Drawing.Size(100, 20);
            this.intRateTextBox.TabIndex = 7;
            // 
            // downPayTextBox
            // 
            this.downPayTextBox.Location = new System.Drawing.Point(144, 87);
            this.downPayTextBox.Name = "downPayTextBox";
            this.downPayTextBox.Size = new System.Drawing.Size(100, 20);
            this.downPayTextBox.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(50, 209);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Residence Type:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(50, 168);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Loan Term (Yrs.):";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(50, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Interest Rate (%):";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Enter Down Payment ($):";
            // 
            // homePriceTextBox
            // 
            this.homePriceTextBox.Location = new System.Drawing.Point(144, 48);
            this.homePriceTextBox.Name = "homePriceTextBox";
            this.homePriceTextBox.Size = new System.Drawing.Size(100, 20);
            this.homePriceTextBox.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter Home Price ($):";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(61, 357);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Monthly Loan Payment:";
            // 
            // monthlyLoanLabel
            // 
            this.monthlyLoanLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.monthlyLoanLabel.Location = new System.Drawing.Point(185, 356);
            this.monthlyLoanLabel.Name = "monthlyLoanLabel";
            this.monthlyLoanLabel.Size = new System.Drawing.Size(100, 24);
            this.monthlyLoanLabel.TabIndex = 2;
            // 
            // monthlyTaxLabel
            // 
            this.monthlyTaxLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.monthlyTaxLabel.Location = new System.Drawing.Point(185, 403);
            this.monthlyTaxLabel.Name = "monthlyTaxLabel";
            this.monthlyTaxLabel.Size = new System.Drawing.Size(100, 24);
            this.monthlyTaxLabel.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(69, 404);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(110, 13);
            this.label9.TabIndex = 4;
            this.label9.Text = "Monthly Property Tax:";
            // 
            // monthlyMortgagePayLabel
            // 
            this.monthlyMortgagePayLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.monthlyMortgagePayLabel.Location = new System.Drawing.Point(185, 450);
            this.monthlyMortgagePayLabel.Name = "monthlyMortgagePayLabel";
            this.monthlyMortgagePayLabel.Size = new System.Drawing.Size(100, 24);
            this.monthlyMortgagePayLabel.TabIndex = 5;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(13, 451);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(166, 13);
            this.label11.TabIndex = 6;
            this.label11.Text = "Total Monthly Mortgage Payment:";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(318, 494);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(87, 38);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(72, 494);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(83, 38);
            this.calcButton.TabIndex = 8;
            this.calcButton.Text = "&Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(194, 494);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(81, 38);
            this.resetButton.TabIndex = 9;
            this.resetButton.Text = "&Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::HIMortgageRate_KS_Project5.Properties.Resources.LittleGrassShack;
            this.pictureBox2.Location = new System.Drawing.Point(12, 56);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(131, 125);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::HIMortgageRate_KS_Project5.Properties.Resources.Rainbow;
            this.pictureBox1.Location = new System.Drawing.Point(449, 56);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(131, 125);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // maxHomePriceLabel
            // 
            this.maxHomePriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.maxHomePriceLabel.Location = new System.Drawing.Point(446, 357);
            this.maxHomePriceLabel.Name = "maxHomePriceLabel";
            this.maxHomePriceLabel.Size = new System.Drawing.Size(100, 24);
            this.maxHomePriceLabel.TabIndex = 12;
            // 
            // aveHomePriceLabel
            // 
            this.aveHomePriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.aveHomePriceLabel.Location = new System.Drawing.Point(446, 404);
            this.aveHomePriceLabel.Name = "aveHomePriceLabel";
            this.aveHomePriceLabel.Size = new System.Drawing.Size(100, 24);
            this.aveHomePriceLabel.TabIndex = 13;
            // 
            // minHomePriceLabel
            // 
            this.minHomePriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.minHomePriceLabel.Location = new System.Drawing.Point(446, 451);
            this.minHomePriceLabel.Name = "minHomePriceLabel";
            this.minHomePriceLabel.Size = new System.Drawing.Size(100, 24);
            this.minHomePriceLabel.TabIndex = 14;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(328, 358);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(112, 13);
            this.label13.TabIndex = 15;
            this.label13.Text = "Maximum Home Price:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(332, 405);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(108, 13);
            this.label14.TabIndex = 16;
            this.label14.Text = "Average Home Price:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(331, 452);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(109, 13);
            this.label15.TabIndex = 17;
            this.label15.Text = "Minimum Home Price:";
            // 
            // resetHousingRecordsButton
            // 
            this.resetHousingRecordsButton.Location = new System.Drawing.Point(449, 494);
            this.resetHousingRecordsButton.Name = "resetHousingRecordsButton";
            this.resetHousingRecordsButton.Size = new System.Drawing.Size(97, 38);
            this.resetHousingRecordsButton.TabIndex = 18;
            this.resetHousingRecordsButton.Text = "Reset &Housing Records";
            this.resetHousingRecordsButton.UseVisualStyleBackColor = true;
            this.resetHousingRecordsButton.Click += new System.EventHandler(this.resetHousingRecordsButton_Click);
            // 
            // HIMortgageCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(591, 552);
            this.Controls.Add(this.resetHousingRecordsButton);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.minHomePriceLabel);
            this.Controls.Add(this.aveHomePriceLabel);
            this.Controls.Add(this.maxHomePriceLabel);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.monthlyMortgagePayLabel);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.monthlyTaxLabel);
            this.Controls.Add(this.monthlyLoanLabel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.mortgageGroupBox);
            this.Name = "HIMortgageCalculator";
            this.Text = "Honolulu Mortgage Calculator";
            this.Load += new System.EventHandler(this.HIMortgageCalculator_Load);
            this.mortgageGroupBox.ResumeLayout(false);
            this.mortgageGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox mortgageGroupBox;
        private System.Windows.Forms.ComboBox resTypeComboBox;
        private System.Windows.Forms.TextBox loanTermTextBox;
        private System.Windows.Forms.TextBox intRateTextBox;
        private System.Windows.Forms.TextBox downPayTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox homePriceTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label monthlyLoanLabel;
        private System.Windows.Forms.Label monthlyTaxLabel;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label monthlyMortgagePayLabel;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.ComboBox stateComboBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label maxHomePriceLabel;
        private System.Windows.Forms.Label aveHomePriceLabel;
        private System.Windows.Forms.Label minHomePriceLabel;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button resetHousingRecordsButton;
    }
}

